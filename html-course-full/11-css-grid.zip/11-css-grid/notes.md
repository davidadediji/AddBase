# CSS Grid

A grid is a layout that has rows and columns

2 x 3

2 == rows
3 == columns
